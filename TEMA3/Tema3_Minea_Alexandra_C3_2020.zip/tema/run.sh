#!/bin/bash
docker-compose -f stack.yml build adapter